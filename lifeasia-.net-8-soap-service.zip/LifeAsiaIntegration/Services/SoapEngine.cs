using System.Globalization;
using System.Xml.Linq;

namespace LifeAsiaIntegration.Services;

/// <summary>
/// Parsed request model extracted from inbound SOAP 1.1 envelope.
/// </summary>
public record LifeAsiaBoRequestData(
    string CompanyCode,
    string PolicyNumber,
    string MemberId,
    string TransactionCode,
    decimal SumAssured,
    string? CorrelationId
);

/// <summary>
/// Result wrapper for SOAP validation and parsing operations.
/// </summary>
public record SoapParseResult(
    bool IsSuccess,
    LifeAsiaBoRequestData? Data,
    string? ErrorMessage,
    string? ErrorCode
);

/// <summary>
/// Core SOAP 1.1 engine utilizing System.Xml.Linq for AS/400 AXIS/HTTPCLI interop.
/// Adheres strictly to SOAP 1.1 specification (http://schemas.xmlsoap.org/soap/envelope/).
/// </summary>
public static class SoapEngine
{
    public static readonly XNamespace Soap11Env = "http://schemas.xmlsoap.org/soap/envelope/";
    public static readonly XNamespace LifeAsiaNs = "http://dxc.com/lifeasia/bo/execution";

    /// <summary>
    /// Parses and strictly validates inbound raw XML payload from AS/400 COBOL.
    /// Handles namespace agnostic retrieval for inner business elements to tolerate
    /// diverse AS/400 XML client generators (AXIS C/C++, HTTPCLI, SQL XMLTABLE).
    /// </summary>
    public static SoapParseResult ParseAndValidate(string rawXml)
    {
        if (string.IsNullOrWhiteSpace(rawXml))
        {
            return new SoapParseResult(
                IsSuccess: false,
                Data: null,
                ErrorMessage: "SOAP request payload is null, empty, or whitespace.",
                ErrorCode: "SOAP_EMPTY_PAYLOAD"
            );
        }

        XDocument doc;
        try
        {
            doc = XDocument.Parse(rawXml, LoadOptions.PreserveWhitespace);
        }
        catch (Exception ex)
        {
            return new SoapParseResult(
                IsSuccess: false,
                Data: null,
                ErrorMessage: $"Malformed XML payload: {ex.Message}",
                ErrorCode: "SOAP_XML_MALFORMED"
            );
        }

        // Verify SOAP Envelope element
        var envelope = doc.Root;
        if (envelope == null || envelope.Name.LocalName != "Envelope" ||
            envelope.Name.Namespace != Soap11Env)
        {
            return new SoapParseResult(
                IsSuccess: false,
                Data: null,
                ErrorMessage: "Root element must be a valid SOAP 1.1 Envelope (http://schemas.xmlsoap.org/soap/envelope/).",
                ErrorCode: "SOAP_INVALID_ENVELOPE"
            );
        }

        // Verify SOAP Body element
        var body = envelope.Element(Soap11Env + "Body");
        if (body == null)
        {
            return new SoapParseResult(
                IsSuccess: false,
                Data: null,
                ErrorMessage: "SOAP Envelope must contain a valid Body element.",
                ErrorCode: "SOAP_MISSING_BODY"
            );
        }

        // Extract operation node (either namespace-qualified or local name 'ExecuteBusinessObjectRequest')
        var operationNode = body.Elements().FirstOrDefault(e =>
            e.Name.LocalName.Equals("ExecuteBusinessObjectRequest", StringComparison.OrdinalIgnoreCase) ||
            e.Name.LocalName.Equals("ExecuteBORequest", StringComparison.OrdinalIgnoreCase));

        if (operationNode == null)
        {
            return new SoapParseResult(
                IsSuccess: false,
                Data: null,
                ErrorMessage: "Target operation node 'ExecuteBusinessObjectRequest' was not found inside SOAP Body.",
                ErrorCode: "SOAP_OPERATION_NOT_FOUND"
            );
        }

        // Helper to retrieve element value case-insensitively
        string? GetElementValue(XElement parent, string localName)
        {
            var match = parent.Elements().FirstOrDefault(e =>
                e.Name.LocalName.Equals(localName, StringComparison.OrdinalIgnoreCase));
            return match?.Value?.Trim();
        }

        var companyCode = GetElementValue(operationNode, "CompanyCode");
        var policyNumber = GetElementValue(operationNode, "PolicyNumber");
        var memberId = GetElementValue(operationNode, "MemberId");
        var transactionCode = GetElementValue(operationNode, "TransactionCode");
        var sumAssuredRaw = GetElementValue(operationNode, "SumAssured");
        var correlationId = GetElementValue(operationNode, "CorrelationId") ?? Guid.NewGuid().ToString("N");

        // Validate mandatory Life/Asia business nodes
        if (string.IsNullOrEmpty(companyCode))
        {
            return new SoapParseResult(false, null, "Required field 'CompanyCode' is missing or empty.", "LA_MISSING_COMPANY_CODE");
        }
        if (string.IsNullOrEmpty(policyNumber))
        {
            return new SoapParseResult(false, null, "Required field 'PolicyNumber' is missing or empty.", "LA_MISSING_POLICY_NUMBER");
        }
        if (string.IsNullOrEmpty(memberId))
        {
            return new SoapParseResult(false, null, "Required field 'MemberId' is missing or empty.", "LA_MISSING_MEMBER_ID");
        }
        if (string.IsNullOrEmpty(transactionCode))
        {
            return new SoapParseResult(false, null, "Required field 'TransactionCode' is missing or empty.", "LA_MISSING_TRANSACTION_CODE");
        }
        if (string.IsNullOrEmpty(sumAssuredRaw))
        {
            return new SoapParseResult(false, null, "Required field 'SumAssured' is missing or empty.", "LA_MISSING_SUM_ASSURED");
        }

        if (!decimal.TryParse(sumAssuredRaw, NumberStyles.Number | NumberStyles.AllowDecimalPoint, CultureInfo.InvariantCulture, out var sumAssured) || sumAssured < 0)
        {
            return new SoapParseResult(false, null, $"Invalid numeric format or negative amount for 'SumAssured': '{sumAssuredRaw}'.", "LA_INVALID_SUM_ASSURED");
        }

        var data = new LifeAsiaBoRequestData(
            CompanyCode: companyCode,
            PolicyNumber: policyNumber,
            MemberId: memberId,
            TransactionCode: transactionCode,
            SumAssured: sumAssured,
            CorrelationId: correlationId
        );

        return new SoapParseResult(true, data, null, null);
    }

    /// <summary>
    /// Builds a compliant SOAP 1.1 Fault XML document for Client errors.
    /// Standardized with soapenv:Fault, faultcode, faultstring, and detail nodes.
    /// </summary>
    public static string BuildSoapFault(string faultString, string errorCode, string? detail = null)
    {
        var faultDoc = new XDocument(
            new XDeclaration("1.0", "utf-8", "yes"),
            new XElement(Soap11Env + "Envelope",
                new XAttribute(XNamespace.Xmlns + "soapenv", Soap11Env.NamespaceName),
                new XElement(Soap11Env + "Body",
                    new XElement(Soap11Env + "Fault",
                        new XElement("faultcode", "soapenv:Client"),
                        new XElement("faultstring", faultString),
                        new XElement("faultactor", "urn:dxc:lifeasia:bo:service"),
                        new XElement("detail",
                            new XElement(LifeAsiaNs + "ErrorDetail",
                                new XAttribute(XNamespace.Xmlns + "la", LifeAsiaNs.NamespaceName),
                                new XElement(LifeAsiaNs + "ErrorCode", errorCode),
                                new XElement(LifeAsiaNs + "ErrorMessage", faultString),
                                new XElement(LifeAsiaNs + "DiagnosticDetails", detail ?? "Validation error encountered while inspecting AS/400 inbound XML stream."),
                                new XElement(LifeAsiaNs + "Timestamp", DateTime.UtcNow.ToString("o"))
                            )
                        )
                    )
                )
            )
        );

        return faultDoc.Declaration?.ToString() + Environment.NewLine + faultDoc.ToString();
    }

    /// <summary>
    /// Builds a compliant SOAP 1.1 Success Response XML document indicating QUEUED status.
    /// Releases the AS/400 COBOL client immediately with tracing identifier and confirmation.
    /// </summary>
    public static string BuildQueuedSoapResponse(Guid trackingId, LifeAsiaBoRequestData requestData)
    {
        var responseDoc = new XDocument(
            new XDeclaration("1.0", "utf-8", "yes"),
            new XElement(Soap11Env + "Envelope",
                new XAttribute(XNamespace.Xmlns + "soapenv", Soap11Env.NamespaceName),
                new XAttribute(XNamespace.Xmlns + "la", LifeAsiaNs.NamespaceName),
                new XElement(Soap11Env + "Body",
                    new XElement(LifeAsiaNs + "ExecuteBusinessObjectResponse",
                        new XElement(LifeAsiaNs + "TrackingId", trackingId.ToString("D")),
                        new XElement(LifeAsiaNs + "CorrelationId", requestData.CorrelationId ?? trackingId.ToString("N")),
                        new XElement(LifeAsiaNs + "Status", "QUEUED"),
                        new XElement(LifeAsiaNs + "CompanyCode", requestData.CompanyCode),
                        new XElement(LifeAsiaNs + "PolicyNumber", requestData.PolicyNumber),
                        new XElement(LifeAsiaNs + "MemberId", requestData.MemberId),
                        new XElement(LifeAsiaNs + "TransactionCode", requestData.TransactionCode),
                        new XElement(LifeAsiaNs + "SumAssured", requestData.SumAssured.ToString("F2", CultureInfo.InvariantCulture)),
                        new XElement(LifeAsiaNs + "EnqueuedAtUtc", DateTime.UtcNow.ToString("o")),
                        new XElement(LifeAsiaNs + "Message", "Life/Asia Business Object task successfully accepted and queued onto MSP broker.")
                    )
                )
            )
        );

        return responseDoc.Declaration?.ToString() + Environment.NewLine + responseDoc.ToString();
    }
}
