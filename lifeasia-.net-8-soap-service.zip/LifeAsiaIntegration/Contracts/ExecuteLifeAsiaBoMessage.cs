namespace LifeAsiaIntegration.Contracts;

/// <summary>
/// Immutable message contract published to the MSP (Managed Service Provider) broker
/// to trigger asynchronous execution of the Life/Asia Business Object (BO).
/// </summary>
public record ExecuteLifeAsiaBoMessage
{
    /// <summary>
    /// Unique tracing identifier generated upon inbound SOAP acceptance.
    /// </summary>
    public required Guid TrackingId { get; init; }

    /// <summary>
    /// IBM AS/400 Correlation identifier (e.g. Job ID or Message ID from AXIS/HTTPCLI).
    /// </summary>
    public required string CorrelationId { get; init; }

    /// <summary>
    /// Life/Asia 2-character or 4-character Company Code (e.g., '01', 'TW01').
    /// </summary>
    public required string CompanyCode { get; init; }

    /// <summary>
    /// 8-character Life/Asia Contract/Policy Header Number (CHDRCOW / CHDRPF).
    /// </summary>
    public required string PolicyNumber { get; init; }

    /// <summary>
    /// Client / Life Insured / Member Identifier (CLNTNUM / CLNTPF).
    /// </summary>
    public required string MemberId { get; init; }

    /// <summary>
    /// Life/Asia Transaction Code (e.g., 'NB' for New Business, 'EN' for Endorsement, 'CV' for Surrender).
    /// </summary>
    public required string TransactionCode { get; init; }

    /// <summary>
    /// Face amount or Sum Assured to be updated or validated by the Business Object.
    /// </summary>
    public required decimal SumAssured { get; init; }

    /// <summary>
    /// UTC timestamp of inbound SOAP receipt.
    /// </summary>
    public DateTime EnqueuedAtUtc { get; init; } = DateTime.UtcNow;

    /// <summary>
    /// Originating client descriptor (e.g. 'AS400-COBOL-HTTPCLI-AXIS').
    /// </summary>
    public string SourceSystem { get; init; } = "IBM_AS400_LIFEASIA_COBOL";
}
