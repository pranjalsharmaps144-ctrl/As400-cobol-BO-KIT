using MassTransit;
using LifeAsiaIntegration.Contracts;
using Microsoft.Extensions.Logging;

namespace LifeAsiaIntegration.Consumers;

/// <summary>
/// Asynchronous MassTransit consumer representing the MSP (Managed Service Provider) worker.
/// Executes the Life/Asia Business Object (BO) logic against DB2/400 or core transaction engines.
/// </summary>
public class LifeAsiaBoConsumer : IConsumer<ExecuteLifeAsiaBoMessage>
{
    private readonly ILogger<LifeAsiaBoConsumer> _logger;

    public LifeAsiaBoConsumer(ILogger<LifeAsiaBoConsumer> logger)
    {
        _logger = logger;
    }

    public async Task Consume(ConsumeContext<ExecuteLifeAsiaBoMessage> context)
    {
        var msg = context.Message;
        var retryCount = context.GetRetryAttempt();

        _logger.LogInformation(
            "==> [LifeAsia-BO-Worker] Processing TrackingId: {TrackingId} | Policy: {PolicyNumber} | TxCode: {TxCode} | RetryAttempt: {RetryAttempt}",
            msg.TrackingId, msg.PolicyNumber, msg.TransactionCode, retryCount);

        try
        {
            // Simulate Life/Asia DB2/400 Mainframe Core BO Execution
            await ExecuteLifeAsiaBusinessObjectAsync(msg, context.CancellationToken);

            _logger.LogInformation(
                "<== [LifeAsia-BO-Worker] COMPLETED: TrackingId: {TrackingId} | Policy: {PolicyNumber} | SumAssured: {SumAssured:C} committed to DB2/400.",
                msg.TrackingId, msg.PolicyNumber, msg.SumAssured);
        }
        catch (Db2RecordLockException ex)
        {
            // Simulates transient DB2/400 record lock (CPF5027 / CPF5009)
            _logger.LogWarning(
                ex,
                "[LifeAsia-BO-Worker] Transient DB2/400 record lock encountered on Policy {PolicyNumber}. Triggering MassTransit retry policy (Attempt {RetryAttempt}).",
                msg.PolicyNumber, retryCount);

            // Re-throw to invoke MassTransit exponential backoff retry pipeline
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(
                ex,
                "[LifeAsia-BO-Worker] Unrecoverable Business Object Fault for TrackingId: {TrackingId} | Policy: {PolicyNumber}. Routing to Dead-Letter Queue (DLQ).",
                msg.TrackingId, msg.PolicyNumber);

            // If configured, MassTransit moves messages that exhaust retries to the _error queue (DLQ)
            throw;
        }
    }

    /// <summary>
    /// Simulates execution of the core Life/Asia Business Object against IBM DB2 for i (OS/400 tables: CHDRPF, COVRPF, TRNPF).
    /// </summary>
    private static async Task ExecuteLifeAsiaBusinessObjectAsync(ExecuteLifeAsiaBoMessage message, CancellationToken ct)
    {
        // Simulate IO / DB2 / RPC processing latency
        await Task.Delay(120, ct);

        // Simulation guard: Test policy 'LOCKTEST' triggers transient record lock to demonstrate retry policy
        if (message.PolicyNumber.StartsWith("LOCK", StringComparison.OrdinalIgnoreCase))
        {
            throw new Db2RecordLockException(
                $"DB2/400 CPF5027: Record lock conflict detected on member CHDRPF for Policy {message.PolicyNumber}.");
        }

        // Simulation guard: Invalid company code triggers permanent failure / DLQ
        if (message.CompanyCode.Equals("ERR", StringComparison.OrdinalIgnoreCase))
        {
            throw new InvalidOperationException(
                $"Life/Asia BO Execution Error: Invalid CompanyCode '{message.CompanyCode}' for Policy {message.PolicyNumber}.");
        }
    }
}

/// <summary>
/// Custom exception representing IBM iSeries / DB2 for i record lock conditions (e.g., CPF5027/CPF5009).
/// </summary>
public class Db2RecordLockException : Exception
{
    public Db2RecordLockException(string message) : base(message) { }
}
