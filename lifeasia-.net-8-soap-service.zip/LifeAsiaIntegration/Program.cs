using System.Text;
using LifeAsiaIntegration.Consumers;
using LifeAsiaIntegration.Contracts;
using LifeAsiaIntegration.Services;
using MassTransit;

var builder = WebApplication.CreateBuilder(args);

// Configure Logging
builder.Logging.ClearProviders();
builder.Logging.AddConsole();
builder.Logging.SetMinimumLevel(LogLevel.Information);

// Configure MSP (Managed Service Provider) Messaging via MassTransit
var messageBrokerProvider = builder.Configuration.GetValue<string>("MspBroker:Provider") ?? "AzureServiceBus";
var serviceBusConnectionString = builder.Configuration.GetConnectionString("AzureServiceBus");

builder.Services.AddMassTransit(x =>
{
    x.AddConsumer<LifeAsiaBoConsumer>();

    if (string.Equals(messageBrokerProvider, "AzureServiceBus", StringComparison.OrdinalIgnoreCase) &&
        !string.IsNullOrWhiteSpace(serviceBusConnectionString))
    {
        x.UsingAzureServiceBus((context, cfg) =>
        {
            cfg.Host(serviceBusConnectionString);

            cfg.ReceiveEndpoint("lifeasia-bo-execution-queue", ep =>
            {
                // Concurrency throttling for mainframe DB2/400 connection limits
                ep.ConcurrentMessageLimit = builder.Configuration.GetValue<int>("MspBroker:ConcurrentMessageLimit", 16);

                // Enterprise Exponential Backoff Retry Policy for transient DB2 record locks
                ep.UseMessageRetry(r => r.Exponential(
                    retryLimit: 5,
                    minInterval: TimeSpan.FromSeconds(1),
                    maxInterval: TimeSpan.FromSeconds(30),
                    intervalDelta: TimeSpan.FromSeconds(2)
                ));

                // Auto-route poison/unrecoverable messages to Dead Letter Queue (DLQ)
                ep.ConfigureConsumer<LifeAsiaBoConsumer>(context);
            });
        });
    }
    else if (string.Equals(messageBrokerProvider, "RabbitMQ", StringComparison.OrdinalIgnoreCase))
    {
        var rabbitHost = builder.Configuration.GetValue<string>("MspBroker:RabbitMQ:Host") ?? "localhost";
        x.UsingRabbitMq((context, cfg) =>
        {
            cfg.Host(rabbitHost, "/", h =>
            {
                h.Username(builder.Configuration.GetValue<string>("MspBroker:RabbitMQ:Username") ?? "guest");
                h.Password(builder.Configuration.GetValue<string>("MspBroker:RabbitMQ:Password") ?? "guest");
            });

            cfg.ReceiveEndpoint("lifeasia-bo-execution-queue", ep =>
            {
                ep.UseMessageRetry(r => r.Exponential(5, TimeSpan.FromSeconds(1), TimeSpan.FromSeconds(30), TimeSpan.FromSeconds(2)));
                ep.ConfigureConsumer<LifeAsiaBoConsumer>(context);
            });
        });
    }
    else
    {
        // Resilient in-memory fallback for local development & automated integration testing
        x.UsingInMemory((context, cfg) =>
        {
            cfg.ReceiveEndpoint("lifeasia-bo-execution-queue", ep =>
            {
                ep.UseMessageRetry(r => r.Exponential(5, TimeSpan.FromSeconds(1), TimeSpan.FromSeconds(30), TimeSpan.FromSeconds(2)));
                ep.ConfigureConsumer<LifeAsiaBoConsumer>(context);
            });
        });
    }
});

var app = builder.Build();

// Route: Inbound SOAP 1.1 Endpoint for IBM AS/400 COBOL (AXIS/HTTPCLI)
app.MapPost("/soap/lifeasia/execute-bo", async (
    HttpContext httpContext,
    IPublishEndpoint publishEndpoint,
    ILogger<Program> logger) =>
{
    // Read raw SOAP request stream from AS/400
    string rawXml;
    using (var reader = new StreamReader(httpContext.Request.Body, Encoding.UTF8))
    {
        rawXml = await reader.ReadToEndAsync();
    }

    logger.LogInformation("Inbound AS/400 SOAP 1.1 request received. Payload length: {ByteCount} chars.", rawXml.Length);

    // Parse and validate SOAP 1.1 payload
    var parseResult = SoapEngine.ParseAndValidate(rawXml);

    if (!parseResult.IsSuccess || parseResult.Data == null)
    {
        logger.LogWarning("SOAP validation failed: {ErrorCode} - {ErrorMessage}", parseResult.ErrorCode, parseResult.ErrorMessage);

        var faultXml = SoapEngine.BuildSoapFault(
            faultString: parseResult.ErrorMessage ?? "Validation failure",
            errorCode: parseResult.ErrorCode ?? "SOAP_VALIDATION_ERROR"
        );

        httpContext.Response.StatusCode = StatusCodes.Status500InternalServerError;
        httpContext.Response.ContentType = "text/xml; charset=utf-8";
        await httpContext.Response.WriteAsync(faultXml, Encoding.UTF8);
        return;
    }

    var data = parseResult.Data;
    var trackingId = Guid.NewGuid();

    // Construct immutable contract to dispatch onto MSP Message Broker
    var message = new ExecuteLifeAsiaBoMessage
    {
        TrackingId = trackingId,
        CorrelationId = data.CorrelationId ?? trackingId.ToString("N"),
        CompanyCode = data.CompanyCode,
        PolicyNumber = data.PolicyNumber,
        MemberId = data.MemberId,
        TransactionCode = data.TransactionCode,
        SumAssured = data.SumAssured,
        EnqueuedAtUtc = DateTime.UtcNow,
        SourceSystem = "IBM_AS400_LIFEASIA_COBOL"
    };

    // Publish to Managed Service Provider (MSP) message queue
    await publishEndpoint.Publish(message);

    logger.LogInformation(
        "Life/Asia BO job queued onto MSP broker. TrackingId: {TrackingId}, Policy: {PolicyNumber}. Immediate response returning to AS/400 to release COBOL job lock.",
        trackingId, data.PolicyNumber);

    // Build standard SOAP 1.1 Success Response (QUEUED status)
    var responseXml = SoapEngine.BuildQueuedSoapResponse(trackingId, data);

    httpContext.Response.StatusCode = StatusCodes.Status200OK;
    httpContext.Response.ContentType = "text/xml; charset=utf-8";
    await httpContext.Response.WriteAsync(responseXml, Encoding.UTF8);
});

app.Run();
